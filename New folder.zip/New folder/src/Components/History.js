import React, { useState, useEffect } from "react";
import * as d3 from "d3";

export default function History(props) {
  const [historicalWeatherData, setHistoricalWeatherData] = useState([]);
  const apiKey = "6c119f9082364891872a340604a40cf5";
  const city = props.city;

  const endDate = new Date().toISOString().split("T")[0];
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 7);
  const startDateString = startDate.toISOString().split("T")[0];

  const historyApiUrl = `https://api.weatherbit.io/v2.0/history/energy?city=${city}
  }&start_date=${startDateString}&end_date=${endDate}&key=${apiKey}&tp=daily`;

  useEffect(() => {
    fetch(historyApiUrl)
      .then((response) => response.json())
      .then((data) => {
        setHistoricalWeatherData(data.data);
      })
      .catch((error) =>
        console.error("Error fetching historical data:", error)
      );
  }, [historyApiUrl]);

  useEffect(() => {
    const svg = d3.select("#historical-chart");
    const svg2 = d3.select("#historical-date");

    svg
      .selectAll("rect")
      .data(historicalWeatherData)
      .join("rect")
      .attr("x", (d, i) => i * (50 + 40))
      .attr("y", (d) => 70 - d.temp)
      .attr("width", 30)
      .attr("height", (d) => d.temp + 180)
      .attr("fill", "blue");

    svg2
      .selectAll("text")
      .data(historicalWeatherData)
      .join("text")
      .text((d) => `${d.temp}°C`)
      .attr("x", (d, i) => i * (50 + 40))
      .attr("y", 80)
      .attr("text-anchor", "middle")
      .attr("fill", "black");

    // svg2
    //   .selectAll("text")
    //   .data(historicalWeatherData)
    //   .join("text")
    //   .text((d) => `${d.datetime.slice(0, -3)}`)
    //   .attr("x", (d, i) => i * (50 + 40))
    //   .attr("y", 80)
    //   .attr("text-anchor", "middle")
    //   .attr("fill", "black");
  }, [historicalWeatherData]);

  console.log("history", historicalWeatherData);

  return (
    <div className="h-80 my-5 w-full bg-white shadow-md rounded-2xl">
      <h2 className="text-start ps-6 pt-2 size-5 font-bold text-gray-500 text-2xl">
        History
      </h2>
      {historicalWeatherData && historicalWeatherData.length === 0 ? (
        <div>Loading historical data...</div>
      ) : (
        <div className="h-72 relative flex justify-center">
          <div className="w-88">
            <svg id="historical-chart" width="600" height="240"></svg>
          </div>
          <div className="absolute w-88 bottom-0">
            <svg id="historical-date" width="600" height="100"></svg>
          </div>
        </div>
      )}
    </div>
  );
}
